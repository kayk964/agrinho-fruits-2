let player;
let fruits = [];
let trashes = [];
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(400, 600);
  player = new Farmer();
}

function draw() {
  background(100, 200, 100); // fundo verde, tipo campo
  
  if (!gameOver) {
    player.show();
    player.move();

    if (frameCount % 60 === 0) {
      if (random() < 0.7) {
        fruits.push(new Drop("fruit"));
      } else {
        trashes.push(new Drop("trash"));
      }
    }

    // Mostrar e verificar frutas
    for (let i = fruits.length - 1; i >= 0; i--) {
      fruits[i].update();
      fruits[i].show();

      if (fruits[i].hits(player)) {
        score++;
        fruits.splice(i, 1);
      } else if (fruits[i].offScreen()) {
        fruits.splice(i, 1);
      }
    }

    // Mostrar e verificar lixos
    for (let i = trashes.length - 1; i >= 0; i--) {
      trashes[i].update();
      trashes[i].show();

      if (trashes[i].hits(player)) {
        gameOver = true;
      } else if (trashes[i].offScreen()) {
        trashes.splice(i, 1);
      }
    }

    fill(255);
    textSize(20);
    text("Pontos: " + score, 10, 30);
  } else {
    textSize(32);
    fill(255, 0, 0);
    textAlign(CENTER);
    text("Fim de Jogo!", width / 2, height / 2 - 20);
    textSize(20);
    text("Pontuação: " + score, width / 2, height / 2 + 20);
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    player.setDir(-1);
  } else if (keyCode === RIGHT_ARROW) {
    player.setDir(1);
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    player.setDir(0);
  }
}

// Classe do fazendeiro
class Farmer {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.dir = 0;
  }

  show() {
    fill(139, 69, 19); // marrom
    rect(this.x, this.y, 40, 20);
  }

  setDir(dir) {
    this.dir = dir;
  }

  move() {
    this.x += this.dir * 5;
    this.x = constrain(this.x, 0, width - 40);
  }
}

// Classe para frutas e lixos
class Drop {
  constructor(type) {
    this.x = random(0, width - 20);
    this.y = 0;
    this.size = 20;
    this.speed = 4;
    this.type = type;
  }

  update() {
    this.y += this.speed;
  }

  show() {
    if (this.type === "fruit") {
      fill(255, 0, 0); // maçã vermelha
      ellipse(this.x + 10, this.y + 10, this.size);
    } else {
      fill(100); // lixo cinza
      rect(this.x, this.y, this.size, this.size);
    }
  }

  offScreen() {
    return this.y > height;
  }

  hits(player) {
    return this.x < player.x + 40 &&
           this.x + this.size > player.x &&
           this.y < player.y + 20 &&
           this.y + this.size > player.y;
  }
}
